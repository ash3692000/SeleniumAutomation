package week1.day1;

public class MainClass {
	
	public static void main(String[] args){
		System.out.println("*** Welcome Home ***");
		
		SplitText splitTextFromGivenText = new SplitText();
		splitTextFromGivenText.getSplitText();
		
		PrimeNumber getPrimeNumber = new PrimeNumber();
		getPrimeNumber.findPrimeOrNot();
		
		FindOccurenceOfCharacterA findOccurence = new FindOccurenceOfCharacterA();
		findOccurence.occurenceOfCharacterA();
	}
}
