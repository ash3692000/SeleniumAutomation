package week1.day1;

public class SplitText {
	
	public void getSplitText(){
		
		/* -- split it and print the country that starts with c -  india&china&america&canada&japan&Chile -- */
		
		String countryName = "india&china&america&canada&japan&Chile";
		String[] splitCountryName = countryName.split("&");
		countryName.equalsIgnoreCase(countryName);
			
		for(int i=0; i<splitCountryName.length; i++){
			if(splitCountryName[i].startsWith("c") || splitCountryName[i].startsWith("C")){
				System.out.println("The country names that starts with c is: "+splitCountryName[i]);
			}
		}
		
	}

}
