package week2.day1;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class SeleniumDropDown {
	
public static void main (String[] args) throws InterruptedException {
		
		// To launch a chrome browser
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\259412\\workspace\\Ashwin\\SelMar\\drivers\\chromedriver.exe");
		ChromeDriver cDriver = new ChromeDriver();
		
		// Launch a website in the chrome browser
		cDriver.get("http://leaftaps.com/opentaps");
		
		// Maximize the chrome browser
		cDriver.manage().window().maximize();
		
		// Form details
		cDriver.findElementById("username").sendKeys("Demosalesmanager");
		cDriver.findElementById("password").sendKeys("crmsfa");
		cDriver.findElementByClassName("decorativeSubmit").click();
		cDriver.findElementByLinkText("CRM/SFA").click();
		cDriver.findElementByLinkText("Create Lead").click();
		cDriver.findElementById("createLeadForm_companyName").sendKeys("Cognizant");
		cDriver.findElementById("createLeadForm_firstName").sendKeys("Ashwin");
		
		WebElement elementSource = cDriver.findElementById("createLeadForm_dataSourceId");
		Select sourceDropDown = new Select(elementSource);
		sourceDropDown.selectByValue("LEAD_CONFERENCE");
		
		cDriver.findElementById("createLeadForm_firstNameLocal").sendKeys("Ashwin");
		cDriver.findElementById("createLeadForm_personalTitle").sendKeys("Mr");
		cDriver.findElementById("createLeadForm_generalProfTitle").sendKeys("Welcome Lead");
		cDriver.findElementById("createLeadForm_annualRevenue").sendKeys("500000");
		
		WebElement elementIndustry = cDriver.findElementById("createLeadForm_industryEnumId");
		Select dropDown = new Select(elementIndustry);
		dropDown.selectByValue("IND_FINANCE");
		
		WebElement elementOwnership = cDriver.findElementById("createLeadForm_ownershipEnumId");
		Select ownershipDropDown = new Select(elementOwnership);
		ownershipDropDown.deselectByValue("OWN_PARTNERSHIP");
		
		cDriver.findElementById("createLeadForm_sicCode").sendKeys("A12345");
		cDriver.findElementById("createLeadForm_description").sendKeys("*** WELCOME HOME ***");
		cDriver.findElementById("createLeadForm_importantNote").sendKeys("Nothing to say");
		cDriver.findElementById("createLeadForm_primaryPhoneCountryCode").clear();
		cDriver.findElementById("createLeadForm_primaryPhoneCountryCode").sendKeys("91");
		cDriver.findElementById("createLeadForm_primaryPhoneAreaCode").sendKeys("100");
		cDriver.findElementById("createLeadForm_primaryPhoneExtension").sendKeys("0427");
		cDriver.findElementById("createLeadForm_primaryEmail").sendKeys("ash3692000@gmail.com");
		cDriver.findElementById("createLeadForm_generalToName").sendKeys("Tom Cruise");
		cDriver.findElementById("createLeadForm_generalAddress1").sendKeys("120, Ram street");
		cDriver.findElementById("createLeadForm_generalCity").sendKeys("Chennai");
		cDriver.findElementById("createLeadForm_generalPostalCode").sendKeys("600100");
		cDriver.findElementById("createLeadForm_generalPostalCodeExt").sendKeys("123");
		cDriver.findElementById("createLeadForm_parentPartyId").sendKeys("Yes");
		cDriver.findElementById("createLeadForm_lastName").sendKeys("Balasubramani");
		
		WebElement elementMarketingCampaign = cDriver.findElementById("createLeadForm_marketingCampaignId");
		Select marketingCampaignDropDown = new Select(elementMarketingCampaign);
		marketingCampaignDropDown.selectByValue("CATRQ_CAMPAIGNS");
		
		cDriver.findElementById("createLeadForm_lastNameLocal").sendKeys("Balu");
		cDriver.findElementById("createLeadForm_birthDate").sendKeys("01/21/89");
		cDriver.findElementById("createLeadForm_departmentName").sendKeys("Software");
		
		WebElement elementPreferredCurrency = cDriver.findElementById("createLeadForm_currencyUomId");
		Select preferredCurrencyDropDown = new Select(elementPreferredCurrency);
		preferredCurrencyDropDown.selectByValue("INR");
		
		cDriver.findElementById("createLeadForm_numberEmployees").sendKeys("75");
		cDriver.findElementById("createLeadForm_tickerSymbol").sendKeys("Yes");
		cDriver.findElementById("createLeadForm_primaryPhoneNumber").sendKeys("9965546369");
		cDriver.findElementById("createLeadForm_primaryPhoneAskForName").sendKeys("Support Team");
		cDriver.findElementById("createLeadForm_primaryWebUrl").sendKeys("https://www.Ashwin.com");
		cDriver.findElementById("createLeadForm_generalAttnName").sendKeys("Ashwin Balasubramani");
		cDriver.findElementById("createLeadForm_generalAddress2").sendKeys("Ammapet, Salem");
		
		WebElement elementCountry = cDriver.findElementById("createLeadForm_generalCountryGeoId");
		Select countryDropDown = new Select(elementCountry);
		countryDropDown.selectByValue("IND");
		Thread.sleep(2000);
		
		WebElement elementState = cDriver.findElementById("createLeadForm_generalStateProvinceGeoId");
		Select stateDropDown = new Select(elementState);
		stateDropDown.selectByValue("IN-TN");
		Thread.sleep(2000);
		
		cDriver.findElementByXPath("//input[@value='Create Lead']").click();
		
			
		
		/*
		 * //To get the values present in the field INDUSTRY drop down WebElement
		 * elementIndustry = cDriver.findElementById("createLeadForm_industryEnumId");
		 * Select dropDown = new Select(elementIndustry);
		 * dropDown.selectByValue("IND_FINANCE"); List<WebElement> options =
		 * dropDown.getOptions(); for (WebElement singleElement : options) { String
		 * textValue = singleElement.getText(); System.out.println(textValue); }
		 * 
		 * cDriver.findElementByClassName("smallSubmit").click();
		 * System.out.println("The title of the page is: "+cDriver.getTitle());
		 */
		
		
		//Thread.sleep(3000);
		//cDriver.close();
		
	}

}
