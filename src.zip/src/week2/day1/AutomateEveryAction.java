package week2.day1;

import org.openqa.selenium.chrome.ChromeDriver;

public class AutomateEveryAction {
	
	public static void main(String[] args){

	
	System.setProperty("webdriver.chrome.driver", "/Users/ashwin/eclipse-workspace/March/drivers/chromedriver");
	ChromeDriver cDriver = new ChromeDriver();
	
	// Launch a website in the chrome browser
	cDriver.get("http://www.leafground.com/pages/Edit.html");
	
	// Maximize the chrome browser
	cDriver.manage().window().maximize();

	}
}

