package week2.day2;

public class AdvancedXPath {
	
	/*
	 * span[text()='To Lead']/following::a span[text()='To Lead']/following::img
	 * 
	 * 
	 * div[text()='Lead ID']/following::tr[1]//a
	 * 
	 * span[text()='Lead List']/following::a[@class='linktext'][6]
	 */
	
	
	
			
}
