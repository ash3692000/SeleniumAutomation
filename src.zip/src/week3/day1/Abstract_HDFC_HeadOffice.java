package week3.day1;

public class Abstract_HDFC_HeadOffice {
	
	public void linkAadhar() {
		System.out.println("The Aadhar is linked");
	}
	
	public void getCreditScore() {
		System.out.println("The Credit Score is good");
	}
	
	
	public static void main(String[] args) {
		
		
		
	}

}
