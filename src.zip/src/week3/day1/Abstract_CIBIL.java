package week3.day1;

public class Abstract_CIBIL {
	
	public void getCIBIL() {
		System.out.println("This is CIBIL");
	}

}
