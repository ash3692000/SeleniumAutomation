package week3.day1;

public class Abstract_RBI {
	
	public void getRBI() {
		System.out.println("This is RBI - Reserve Bank of India");
	}

}
